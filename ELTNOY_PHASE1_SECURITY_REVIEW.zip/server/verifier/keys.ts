import { createCipheriv, createDecipheriv, createPrivateKey, createPublicKey, randomBytes, sign, verify, type KeyObject } from 'node:crypto';
import { readFileSync, statSync } from 'node:fs';
import { VerifierConfigurationError, type VerifierConfig } from './config.js';

export interface VerifierSigningKeys {
  readonly keyId: string;
  sign(payload: Uint8Array): string;
  verify(keyId: string, payload: Uint8Array, signature: string): boolean;
}

export interface EncryptedMfaSecret {
  readonly keyVersion: number;
  readonly nonce: Buffer;
  readonly ciphertext: Buffer;
  readonly tag: Buffer;
}

export interface VerifierMfaKeys {
  readonly activeKeyVersion: number;
  encrypt(secret: Uint8Array, factorId: string, userId: string): EncryptedMfaSecret;
  decrypt(envelope: EncryptedMfaSecret, factorId: string, userId: string): Buffer;
  destroy(): void;
}

export interface VerifierKeys {
  readonly signing: VerifierSigningKeys;
  readonly mfa: VerifierMfaKeys;
  destroy(): void;
}

export class VerifierCryptographicError extends Error {
  constructor(readonly code:
    | 'MFA_KEY_UNAVAILABLE'
    | 'MFA_KEY_VERSION_UNSUPPORTED'
    | 'MFA_CONTEXT_INVALID'
    | 'MFA_SECRET_INVALID'
    | 'MFA_CIPHERTEXT_INVALID'
    | 'MFA_SECRET_ENCRYPT_FAILED'
    | 'MFA_SECRET_DECRYPT_FAILED') {
    super(code);
    this.name = 'VerifierCryptographicError';
  }
}

function readPrivateFile(path: string): Buffer {
  try {
    const metadata = statSync(path);
    if (!metadata.isFile() || (metadata.mode & 0o077) !== 0) {
      throw new VerifierConfigurationError('VERIFIER_KEY_LOAD_FAILED');
    }
    return readFileSync(path);
  } catch {
    throw new VerifierConfigurationError('VERIFIER_KEY_LOAD_FAILED');
  }
}

function associatedData(version: number, factorId: string, userId: string): Buffer {
  if (
    !Number.isSafeInteger(version)
    || version < 1
    || factorId.length < 1
    || factorId.length > 128
    || userId.length < 1
    || userId.length > 128
  ) {
    throw new VerifierCryptographicError('MFA_CONTEXT_INVALID');
  }
  return Buffer.from(`ELTNOY:official-totp:v${version}:${userId}:${factorId}`, 'utf8');
}

function createSigningKeys(privateKey: KeyObject, keyId: string): VerifierSigningKeys {
  const publicKey = createPublicKey(privateKey);
  return Object.freeze({
    keyId,
    sign(payload: Uint8Array) {
      return sign(null, payload, privateKey).toString('base64url');
    },
    verify(candidateKeyId: string, payload: Uint8Array, signature: string) {
      if (candidateKeyId !== keyId || !/^[A-Za-z0-9_-]{86}$/.test(signature)) return false;
      try {
        return verify(null, payload, publicKey, Buffer.from(signature, 'base64url'));
      } catch {
        return false;
      }
    },
  });
}

function createMfaKeys(key: Buffer, keyVersion: number): VerifierMfaKeys {
  let destroyed = false;
  return Object.freeze({
    activeKeyVersion: keyVersion,
    encrypt(secret: Uint8Array, factorId: string, userId: string) {
      if (destroyed) throw new VerifierCryptographicError('MFA_KEY_UNAVAILABLE');
      if (secret.byteLength !== 20) throw new VerifierCryptographicError('MFA_SECRET_INVALID');
      try {
        const nonce = randomBytes(12);
        const cipher = createCipheriv('aes-256-gcm', key, nonce);
        cipher.setAAD(associatedData(keyVersion, factorId, userId));
        const ciphertext = Buffer.concat([cipher.update(secret), cipher.final()]);
        return { keyVersion, nonce, ciphertext, tag: cipher.getAuthTag() };
      } catch {
        throw new VerifierCryptographicError('MFA_SECRET_ENCRYPT_FAILED');
      }
    },
    decrypt(envelope: EncryptedMfaSecret, factorId: string, userId: string) {
      if (destroyed) throw new VerifierCryptographicError('MFA_KEY_UNAVAILABLE');
      if (envelope.keyVersion !== keyVersion) throw new VerifierCryptographicError('MFA_KEY_VERSION_UNSUPPORTED');
      if (envelope.nonce.byteLength !== 12 || envelope.tag.byteLength !== 16 || envelope.ciphertext.byteLength !== 20) {
        throw new VerifierCryptographicError('MFA_CIPHERTEXT_INVALID');
      }
      try {
        const decipher = createDecipheriv('aes-256-gcm', key, envelope.nonce);
        decipher.setAAD(associatedData(keyVersion, factorId, userId));
        decipher.setAuthTag(envelope.tag);
        return Buffer.concat([decipher.update(envelope.ciphertext), decipher.final()]);
      } catch {
        throw new VerifierCryptographicError('MFA_SECRET_DECRYPT_FAILED');
      }
    },
    destroy() {
      if (!destroyed) key.fill(0);
      destroyed = true;
    },
  });
}

export function loadVerifierKeys(config: VerifierConfig): VerifierKeys {
  const signingFile = readPrivateFile(config.signingKeyFile);
  let mfaKey: Buffer | undefined;
  try {
    const privateKey = createPrivateKey(signingFile);
    if (privateKey.asymmetricKeyType !== 'ed25519') {
      throw new VerifierConfigurationError('VERIFIER_KEY_LOAD_FAILED');
    }
    mfaKey = readPrivateFile(config.mfaKeyFile);
    if (mfaKey.byteLength !== 32) {
      throw new VerifierConfigurationError('VERIFIER_KEY_LOAD_FAILED');
    }
    const encryptionKey = Buffer.from(mfaKey);
    const signing = createSigningKeys(privateKey, config.signingKeyId);
    const mfa = createMfaKeys(encryptionKey, config.mfaKeyVersion);
    return Object.freeze({
      signing,
      mfa,
      destroy() {
        mfa.destroy();
      },
    });
  } catch {
    mfaKey?.fill(0);
    throw new VerifierConfigurationError('VERIFIER_KEY_LOAD_FAILED');
  } finally {
    signingFile.fill(0);
    mfaKey?.fill(0);
  }
}
