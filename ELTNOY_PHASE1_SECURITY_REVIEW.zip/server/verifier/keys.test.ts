import assert from 'node:assert/strict';
import { generateKeyPairSync, randomBytes } from 'node:crypto';
import { chmod, mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import { parseVerifierConfig } from './config.js';
import { loadVerifierKeys, VerifierCryptographicError } from './keys.js';

async function withTemporaryKeys(work: (environment: Record<string, string>) => Promise<void>): Promise<void> {
  const directory = await mkdtemp(join(tmpdir(), 'eltnoy-verifier-test-'));
  try {
    const pair = generateKeyPairSync('ed25519');
    const privatePath = join(directory, 'signing.pem');
    const mfaPath = join(directory, 'mfa.key');
    await writeFile(privatePath, pair.privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
    await writeFile(mfaPath, randomBytes(32), { mode: 0o600 });
    await chmod(privatePath, 0o600);
    await chmod(mfaPath, 0o600);
    await work({
      VERIFIER_BIND_HOST: '127.0.0.1',
      VERIFIER_PORT: '4317',
      VERIFIER_AUTH_ORIGIN: 'http://localhost:3001',
      VERIFIER_SIGNING_KEY_FILE: privatePath,
      VERIFIER_SIGNING_KEY_ID: 'test-signing-v1',
      VERIFIER_MFA_KEY_FILE: mfaPath,
      VERIFIER_MFA_KEY_VERSION: '1',
    });
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
}

test('loads disposable keys, signs/verifies, and encrypts MFA secrets with identity binding', async () => {
  await withTemporaryKeys(async (environment) => {
    const keys = loadVerifierKeys(parseVerifierConfig(environment));
    try {
      const payload = Buffer.from('synthetic assertion');
      const signature = keys.signing.sign(payload);
      assert.equal(keys.signing.verify('test-signing-v1', payload, signature), true);
      assert.equal(keys.signing.verify('wrong-key-id', payload, signature), false);

      const secret = randomBytes(20);
      const encrypted = keys.mfa.encrypt(secret, 'factor-test', 'user-test');
      assert.deepEqual(keys.mfa.decrypt(encrypted, 'factor-test', 'user-test'), secret);
      assert.throws(
        () => keys.mfa.decrypt(encrypted, 'factor-other', 'user-test'),
        (error: unknown) => error instanceof VerifierCryptographicError && error.code === 'MFA_SECRET_DECRYPT_FAILED',
      );
      assert.throws(
        () => keys.mfa.decrypt({ ...encrypted, keyVersion: 2 }, 'factor-test', 'user-test'),
        (error: unknown) => error instanceof VerifierCryptographicError && error.code === 'MFA_KEY_VERSION_UNSUPPORTED',
      );
      secret.fill(0);
    } finally {
      keys.destroy();
    }
  });
});

test('key-loading failures are sanitized and do not disclose paths', async () => {
  await withTemporaryKeys(async (environment) => {
    await assert.rejects(
      async () => loadVerifierKeys(parseVerifierConfig({
        ...environment,
        VERIFIER_MFA_KEY_FILE: join(tmpdir(), 'missing-verifier-test-key'),
      })),
      (error: unknown) => error instanceof Error
        && error.message === 'VERIFIER_KEY_LOAD_FAILED'
        && !error.message.includes(environment.VERIFIER_SIGNING_KEY_FILE),
    );
  });
});
