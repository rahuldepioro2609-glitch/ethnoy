import assert from 'node:assert/strict';
import { generateKeyPairSync, randomUUID, sign, verify } from 'node:crypto';
import test from 'node:test';
import { createOfficialAuthenticationAssertion, verifyOfficialAuthenticationAssertion } from './assertions.js';
import type { VerifierSigningKeys } from './keys.js';
import { sha256Hex, validateAuthenticationTransaction, VerifierProtocolError, type AuthenticationTransaction, type ExpectedTransactionBinding } from './transactions.js';

const NOW = 1_800_000_000;
const binding: ExpectedTransactionBinding = {
  transactionId: randomUUID(),
  userId: 'synthetic-official-1',
  purpose: 'official_login',
  challenge: 'c'.repeat(43),
  browserBinding: 'b'.repeat(43),
};
const transaction: AuthenticationTransaction = {
  transactionId: binding.transactionId,
  userId: binding.userId,
  purpose: binding.purpose,
  challengeHash: sha256Hex(binding.challenge),
  browserBindingHash: sha256Hex(binding.browserBinding),
  createdAt: NOW - 10,
  expiresAt: NOW + 600,
  state: 'pending',
};

class TestAssertionReplayStore {
  private readonly consumed = new Set<string>();

  async consumeOnce(assertionId: string): Promise<boolean> {
    if (this.consumed.has(assertionId)) return false;
    this.consumed.add(assertionId);
    return true;
  }
}

function testSigningKeys(): VerifierSigningKeys {
  const pair = generateKeyPairSync('ed25519');
  return {
    keyId: 'test-key-v1',
    sign(payload) {
      return sign(null, payload, pair.privateKey).toString('base64url');
    },
    verify(keyId, payload, signature) {
      if (keyId !== 'test-key-v1') return false;
      return verify(null, payload, pair.publicKey, Buffer.from(signature, 'base64url'));
    },
  };
}

test('transaction validation binds user, purpose, challenge, and browser', () => {
  assert.equal(validateAuthenticationTransaction(transaction, binding, NOW).userId, binding.userId);
  assert.throws(
    () => validateAuthenticationTransaction(transaction, { ...binding, challenge: 'd'.repeat(43) }, NOW),
    (error: unknown) => error instanceof VerifierProtocolError && error.code === 'AUTH_CHALLENGE_INVALID',
  );
  assert.throws(
    () => validateAuthenticationTransaction(transaction, { ...binding, browserBinding: 'e'.repeat(43) }, NOW),
    (error: unknown) => error instanceof VerifierProtocolError && error.code === 'AUTH_BROWSER_BINDING_INVALID',
  );
  assert.throws(
    () => validateAuthenticationTransaction({ ...transaction, state: 'consumed' }, binding, NOW),
    (error: unknown) => error instanceof VerifierProtocolError && error.code === 'AUTH_TRANSACTION_INVALID',
  );
});

test('assertion has a 30-second lifetime and verifies the intended proof purpose', () => {
  const signingKeys = testSigningKeys();
  const assertion = createOfficialAuthenticationAssertion({ transaction, expected: binding, signingKeys, nowSeconds: NOW });
  assert.equal(assertion.claims.expiresAt - assertion.claims.issuedAt, 30);
  assert.equal(verifyOfficialAuthenticationAssertion({ ...binding, assertion }, signingKeys, NOW).userId, binding.userId);
  assert.throws(
    () => verifyOfficialAuthenticationAssertion({ ...binding, purpose: 'official_enrolment', assertion }, signingKeys, NOW),
    (error: unknown) => error instanceof VerifierProtocolError && error.code === 'WRONG_PROOF_PURPOSE',
  );
});

test('assertion expiry observes the approved five-second skew and then rejects', () => {
  const signingKeys = testSigningKeys();
  const assertion = createOfficialAuthenticationAssertion({ transaction, expected: binding, signingKeys, nowSeconds: NOW });
  assert.doesNotThrow(() => verifyOfficialAuthenticationAssertion({ ...binding, assertion }, signingKeys, NOW + 35));
  assert.throws(
    () => verifyOfficialAuthenticationAssertion({ ...binding, assertion }, signingKeys, NOW + 36),
    (error: unknown) => error instanceof VerifierProtocolError && error.code === 'ASSERTION_EXPIRED',
  );
});

test('assertion issued beyond the five-second future skew is rejected', () => {
  const signingKeys = testSigningKeys();
  const assertion = createOfficialAuthenticationAssertion({
    transaction,
    expected: binding,
    signingKeys,
    nowSeconds: NOW + 10,
  });
  assert.throws(
    () => verifyOfficialAuthenticationAssertion({ ...binding, assertion }, signingKeys, NOW),
    (error: unknown) => error instanceof VerifierProtocolError && error.code === 'ASSERTION_NOT_YET_VALID',
  );
});

test('assertion IDs can be detected as replayed by the test-only replay store', async () => {
  const signingKeys = testSigningKeys();
  const assertion = createOfficialAuthenticationAssertion({ transaction, expected: binding, signingKeys, nowSeconds: NOW });
  const replay = new TestAssertionReplayStore();
  const claims = verifyOfficialAuthenticationAssertion({ ...binding, assertion }, signingKeys, NOW);
  assert.equal(await replay.consumeOnce(claims.assertionId), true);
  assert.equal(await replay.consumeOnce(claims.assertionId), false);
});
